<?php
require 'header.php';
?><div class="conteudo-principal">
<?php
    require 'produto.php';
?>		 
	</div>
<?php
    require 'footer.php'
?>
