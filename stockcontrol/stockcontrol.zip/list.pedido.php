<?php
require 'header.php';
?><div class="conteudo-principal">
<?php
    require 'pedido.php';
?>		 
	</div>	
<?php
    require 'footer.php'
?>
