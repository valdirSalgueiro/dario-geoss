<?php
require 'header.php';
?><div class="conteudo-principal">
<?php
    require 'venda.php';
?>	
	</div>	
<?php
    require 'footer.php'
?>
