			</div>
		</div>
	</div>
	<div class="footer ng-scope">	
		<div class="company-info">
			<div class="content">
				<p class="copyright">© 2014 - Todos direitos reservados.</p>
			</div>
		</div>	
	</div>    
</body>
</html>