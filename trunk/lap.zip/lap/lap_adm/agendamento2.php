<?

session_start();

$usuario_autenticado=$_SESSION["usuario_autenticado"];

if($usuario_autenticado!=NULL)

{
 
 include('estilo.css');
 include('conn.php');
 include('data.php');

}

else

{

 echo "<script>alert('A sess�o expirou, � preciso fazer o login novamente');

 top.location='index.php';</script>";

}

?>

<html>
	<style type="text/css">
<!--
body {
	background-image: url(img/background.PNG);
}
</style>
<style type="text/css">
<!--
.style1 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
}
-->
</style>

<link href="estilo.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style3 {
	color: #000033;
	font-weight: bold;
}
-->
</style>
<body class=fonte>

<form name="demoform" method=post>

<h1 class="style3"><font face=verdana>Calend&aacute;rio de Agendamento:</font></h1>
<hr color=black size=2>

<span class="style1"><br>
</span><br>
<table border=0 class=fonte>


<tr>
<?
//Contando o n�mero de agendamentos para a data
$data = date("d/m/Y");
$consulta = mysql_query("SELECT count(data) as total FROM agendamentos WHERE data = '".$data."' ") or die(mysql_error());
$total =  mysql_result($consulta,0,"total");
if($_POST['ver']!=NULL)

  {
   printf("<script>
   window.location='agendados.php';</script>");

  }
if($total==15){
echo "Limite de 15 agendamentos alcan�ado para a data $data. <input type=submit name=ver value=Ver class=botao> ";
die();
}

?>
  <td width="174">Data  :</td>
  <td width="367"><input name="dc" value="" size="11"><a href="javascript:void(0)" onClick="if(self.gfPop)gfPop.fPopCalendar(document.demoform.dc);return false;" HIDEFOCUS><img class="PopcalTrigger" align="absmiddle" src="HelloWorld/calbtn.gif" width="34" height="22" border="0" alt=""></a><span class="style1"> &nbsp;</span></td>
</tr>
<tr>
  <td>Paciente :</td>
  <td><input name=nome type=text class=botao id="nome" size=50 maxlength=11></td>
</tr>
<iframe width=174 height=189 name="gToday:normal:agenda.js" id="gToday:normal:agenda.js" src="HelloWorld/ipopeng.htm" scrolling="no" frameborder="0" style="visibility:visible; z-index:999; position:absolute; top:-500px; left:-500px;"></iframe>
<tr>
  <td>M&eacute;dico :</td>
  <td><select name="id_med" class="caixa" id="id_med">
    <?
$busca_med="select * from medico order by nome asc;";
$res_busca_med=mysql_query($busca_med,$conn);
$num_med=mysql_num_rows($res_busca_med);
if($num_med==0)
{
 printf("<option value=''>Nenhum m&eacute;dico encontrado");
}

else

{

 printf("<option value=''>");

 for($x=0;$x<$num_med;$x++)

 {

  $campo_med=mysql_fetch_array($res_busca_med);

  printf("<option value='$campo_med[nome]'>$campo_med[nome]");
  

 }

}

?>
  </select></td>
</tr>
<tr>
  <td>Telefone:</td>
  <td><input name=ddd type=text class=botao id="ddd" size=3 maxlength=3>
    -
      <input name=telefone type=text class=botao id="telefone" size=8 maxlength=8></td>
</tr>
<tr>
  <td>Conv&ecirc;nio :</td>
  <td><select name="convenio" class="caixa" id="convenio">
    <?
$busca_conv="select * from convenio order by nome asc;";
$res_busca_conv=mysql_query($busca_conv,$conn);
$num_conv=mysql_num_rows($res_busca_conv);
if($num_conv==0)
{
 printf("<option value=''>Nenhum Conv&ecirc;nio encontrado");
}

else

{

 printf("<option value=''>");

 for($x=0;$x<$num_conv;$x++)

 {

  $campo_conv=mysql_fetch_array($res_busca_conv);

  printf("<option value='$campo_conv[nome]'>$campo_conv[nome]");
  

 }

}

?>
  </select></td>
</tr>
<tr>
  <td></td>
  <td>&nbsp;</td>
</tr>
<tr><td></td><td><input type=submit value='Agendar' class=botao> 
<input type=submit value='Cancelar' class=botao>
<span class="atributos_titulo">
<input name="button" type=button class="botao" onClick="history.go(-1);" value="Voltar">
</span></td>
</tr>
</table>

</form>
<?

$data = date("d/m/Y");
$nome=$_POST['nome'];
$ex_status_id=$_POST['ex_status_id'];


 $busca_ex.="select * from agendamentos  WHERE data = '".$data."' order by id asc;";
 $res_busca_ex=mysql_query($busca_ex,$conn);
 $num_ex=mysql_num_rows($res_busca_ex);

 if($num_ex>0)

 {

  echo "<table border=1 bordercolor=black class=fonte>";
  echo "<tr><th bordercolor=white>N�mero</th><th bordercolor=white>Nome Paciente</th><th bordercolor=white>M�dico</th><th bordercolor=white>Data Agendamento</th><th bordercolor=white>Convenio</th><th bordercolor=white>Telefone</th><th bordercolor=white>A��o</th></tr>";

  for($x=0;$x<$num_ex;$x++)

  {

   $campo_ex=mysql_fetch_array($res_busca_ex);
   $i++;
   //Busca o Status do ID
   $busca_ex2="select * from ex_status where id = '".$campo_ex[ex_status_id]."';";
   $res_busca_ex2=mysql_query($busca_ex2,$conn);
   $campo_ex2=mysql_fetch_array($res_busca_ex2);
   //Busca o ID do paciente
   $busca_pa="select * from paciente where id = '".$campo_ex[paciente_id]."';";
   $res_busca_pa=mysql_query($busca_pa,$conn);
   $campo_pa=mysql_fetch_array($res_busca_pa);
   
     echo "<tr height=20><td bordercolor=white>$i</td><td bordercolor=white>$campo_ex[paciente]</td>&nbsp;&nbsp;<td bordercolor=white>$campo_ex[medico]</td><td bordercolor=white>&nbsp;&nbsp;$campo_ex[data]</td><td bordercolor=white>&nbsp;&nbsp;$campo_ex[convenio]</td><td bordercolor=white>&nbsp;&nbsp;($campo_ex[ddd]) $campo_ex[telefone]</td><td bordercolor=white><a href='excluir.php?id=$campo_ex[id]' target='conteudo'>Excluir</a>&nbsp;&nbsp;/&nbsp;&nbsp;<a href='alterar.php?id=$campo_ex[id]' target='conteudo'>Alterar</td></a></tr>";

  }

  echo "</table>";

  echo $num_ex;

  if($num_ex==1)

  {

   echo " Registro.";

  }

  else

  {

   echo " Registros.";

  }

 }

 else

 {

  echo "Foi procurado por todo o banco de dados mas n�o foi encontrada nenhum registro para a data de $data.";

 }

?>
<?
//Excluindo um agendamento
if($_POST['excluir']){
$sql = mysql_query("DELETE FROM agendamentos WHERE id = '".$campo_ex[id]."'") or die(mysql_error());
  printf("<script>alert('Excluido.');
   window.location='agendamento.php';</script>");
}


?>
<?
$dc=$_POST['dc'];
$nome=$_POST['nome'];
$id_med=$_POST['id_med'];
$ddd=$_POST['ddd'];
$telefone=$_POST['telefone'];
$convenio=$_POST['convenio'];
$por=$_SESSION["usuario_autenticado"];
$data_cadastro=mktime();

if(($dc!=NULL)and($nome!=NULL)and($ddd!=NULL)and($telefone!=NULL)and($convenio!=NULL))

{

 $busca_equipamento="select * from agendamentos where paciente = '".$nome."' and data = '".$_POST['dc']."' ;";

 $res_busca_equipamento=mysql_query($busca_equipamento,$conn);

 $num_equipamento=mysql_num_rows($res_busca_equipamento);

 if($num_equipamento==0)

 {

    $cad_equipamento="insert into agendamentos values ('','".$dc."','".$nome."','".$id_med."','".$ddd."','".$telefone."','".$convenio."','".$por."','".$data_cadastro."');";

  $ok=mysql_query($cad_equipamento,$conn);

  if($ok==1)

  {

   printf("<script>alert('Agendado.');
   window.location='agendamento.php';</script>");

  }

  else

  {

   echo "ERRO: ".mysql_error($conn).".";

  }

 }

 else

 {

  echo "<script>alert('O paciente: $nome j� est� cadastrado para $data');</script>";

 }

}

?>

</body>

</html>

