<html><head>


<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="Thu, 01 Jan 1970 00:00:00 GMT">
<meta http-equiv="Cache-Control" content="no-store"><title>F�rmula Academia</title>

<script language="JavaScript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
window.open(theURL,winName,features);
}
//-->
</script>
<link href="images/style.css" rel="stylesheet" type="text/css">
<meta name="keywords" content="Carlos Jr, Gera��o Esporte">
<script language="JavaScript" src="images/scripts.js" type="text/javascript"></script>

<style>
#menu1{
position:absolute; visibility: hidden;}
</style><style>
#menu2{
position:absolute; visibility: hidden;}
</style><style>
#menu3{
position:absolute; visibility: hidden;}
</style><style>
#menu4{
position:absolute; visibility: hidden;}
</style><style>
#menu5{
position:absolute; visibility: hidden;}
</style><style>
#menu6{
position:absolute; visibility: hidden;}
</style><style>
#menu7{
position:absolute; visibility: hidden;}
</style><style>
#menu8{
position:absolute; visibility: hidden;}
</style><style>
#menu9{
position:absolute; visibility: hidden;}
</style><style>
#menu10{
position:absolute; visibility: hidden;}
</style><style>
#menu11{
position:absolute; visibility: hidden;}
</style><style>
#menu12{
position:absolute; visibility: hidden;}
.style2 {font-size: 9px}
.style3 {color: #FFFFFF}
</style></head><body style="background-position: center;" topmargin="0" leftmargin="0" rightmargin="0" background="images/back_1600.gif"> 
<center>
  <a href="http://www.revistaphp.com.br/cadastro.php" target="_blank"><img src="imgs/revista.gif" width="568" height="634" border="0"></a>
	</center>
</body></html>