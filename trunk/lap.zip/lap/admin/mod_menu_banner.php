<?

session_start();
?>
<style>
.acesso { font-family:Arial; font-size:11px; font-weight:bold; color:#FFFFFF; }
.titulo { font-family:Arial; font-size:18px; font-weight:bold; color:#333333; }
.atributos_titulo { font-family:Arial; font-size:11px; font-weight:bold; color:#333333; }
.materia { font-family:Tahoma; font-size:11px; color:#2D2D2D; }
.arquivo { font-family:Arial; font-size:12px; font-weight:bold; color:#FFFFFF; }
.meses { font-family:Arial; font-size:11px; font-weight:bold; color:#F6F6F6; }
.por { font-family:Verdana; font-size:10px; font-weight:bold; color:#000000; }
.comentarios_italico { font-family:Tahoma; font-size:11px;  color:#333333; font-style:italic;}
.fonte_cinza { font-family:Arial; font-size:11px; color:#666666; }
.comentarios_responsabilidade { font-family:Verdana; font-size:11px; color:#666666; font-style:italic;}
.email_materia { font-family:Verdana; font-size:12px; font-weight:bold; color:#666666;}


a.l_meses:link    { text-decoration: none; color:#FFFFFF; font-size:11px; }
a.l_meses:visited { text-decoration: none; color:#FFFFFF; font-size:11px; }
a.l_meses:active  { text-decoration: none; color:#FFFFFF; font-size:11px; }
a.l_meses:hover   { text-decoration: none; background-color:#FFFFFF; color:#333333; font-size:11px; }

a.l_menu_materia:link    { text-decoration: none; color:#333333; font-size:11px; }
a.l_menu_materia:visited { text-decoration: none; color:#333333; font-size:11px; }
a.l_menu_materia:active  { text-decoration: none; color:#333333; font-size:11px; }
a.l_menu_materia:hover   { text-decoration: none; background-color:#E9E9E9; color:#000000; font-size:11px; }

a.menu_principal:link    { text-decoration: none; color:#333333; font-size:11px;}
a.menu_principal:visited { text-decoration: none; color:#333333; font-size:11px;}
a.menu_principal:hover   { text-decoration: none; color:#000000; font-size:11px; font-weight:bold}
a.menu_principal:active  { text-decoration: none; color:#33333; font-size:11px;}
.style6 {


	font-size: 12px;



	font-weight: bold;



	font-family: Arial, Helvetica, sans-serif;
}
.style81 {color: #FFFFFF}
-->
</style>

<tr>
  <td width="284"><br /></td>
</tr>
<table width="204" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="20" background="../images/bg.jpg" class="style27"><div align="left" class="style11 style25">
      <div align="center"><strong><span class="style81">Menu:</span></strong></div>
    </div></td>
  </tr>
</table>
<br />
<br />
<table width="200" border="0" align="center" class="por">
  <tr>
    <td><div align="center"><a href="mod_foto_banner_noticias.php" class="materia">Imagem</a></div></td>
  </tr>
  <tr>
    <td><div align="center"><a href="mod_flash.php" class="materia">Flash</a></div></td>
  </tr>
  <tr>
    <td><div align="center"><a href="mod_google.php" class="materia">C&oacute;digo Google</a></div></td>
  </tr>
</table>
<br />
<table width="204" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="20" background="../images/bg.jpg" class="style27"><div align="left" class="style11 style25">
      <div align="center"></div>
    </div></td>
  </tr>
</table>
<br />
</table>
</form>
</body>

</html>

