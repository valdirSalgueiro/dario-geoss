<html>
<style>
body {BACKGROUND-ATTACHMENT: fixed;
background-position: center center;
background-repeat: no-repeat;}
</style>
<body background="imagens/LOGEMAIL.JPG">
</body>
</html>
