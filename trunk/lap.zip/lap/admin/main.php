<html>

<frameset border="0" cols="200,*">

<frame src="menu.php"  name="menu" scrolling="auto">

<frame src="conteudo.php" name="conteudo" scrolling="auto">

</frameset><noframes></noframes>

</html>



