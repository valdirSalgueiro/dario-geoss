<html>
<head><STYLE><!--A {text-decoration: none;}A:HOVER {text-decoration:
underline;}--></STYLE>
<title>||||||| Hand Line ||||||||</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" link="#000000" vlink="#000000" alink="#000000">
<table width="778" border="0" cellpadding="0" cellspacing="0" height="850" align="center">
  <tr> 
    <td height="108" valign="top" colspan="2"><img src="layout/projeto_r1_c1.jpg" width="271" height="113"><img src="layout/projeto_r1_c2.jpg" width="271" height="113"><img src="layout/projeto_r1_c3.jpg" width="238" height="113" usemap="#Map" border="0"></td>
  </tr>
  <tr> 
    <td width="662" height="726" background="layout/projeto_r2_c1.jpg" valign="top"> 
      <br>

      <font face="Geneva, Arial, Helvetica, san-serif" size="3"><b>Cota��o de 
      Frete Mar�timo</b></font> 
      <p class=corpodetexto><font face="Geneva, Arial, Helvetica, san-serif" size="2"><b><font color="#FF9900">Para 
        fazer uma tomada de pre�os para a Hand Line preencha o formul�rio abaixo.</font></b></font></p>
      <table class=corpodetexto_bold width=540 border=0 align="center" height="595">
        <form action=cotacao.php method=post>
          <font face="Geneva, Arial, Helvetica, san-serif" size="2"><tbody>
          </font> 
          <tr valign=top> 
            <td colspan=2> <font face="Geneva, Arial, Helvetica, san-serif" size="2"> 
              <input type=hidden value=mar name=tipo>

              </font></td>
          </tr>
          <tr> 
            <td><font face="Geneva, Arial, Helvetica, san-serif" size="2">Nome(*): 
              </font></td>
            <td> <font face="Geneva, Arial, Helvetica, san-serif" size="2"> 
              <input class=formbox maxlength=60 size=40 name=nome>
              </font></td>
          </tr>
          <tr> 
            <td><font face="Geneva, Arial, Helvetica, san-serif" size="2">Empresa(*):</font></td>

            <td> <font face="Geneva, Arial, Helvetica, san-serif" size="2"> 
              <input class=formbox maxlength=60 size=40 name=empresa>
              </font></td>
          </tr>
          <tr> 
            <td><font face="Geneva, Arial, Helvetica, san-serif" size="2">Cargo:</font></td>
            <td> <font face="Geneva, Arial, Helvetica, san-serif" size="2"> 
              <input class=formbox maxlength=40 size=40 name=cargo>
              </font></td>

          </tr>
          <tr> 
            <td><font face="Geneva, Arial, Helvetica, san-serif" size="2">E-mail(*):</font></td>
            <td> <font face="Geneva, Arial, Helvetica, san-serif" size="2"> 
              <input class=formbox maxlength=40 size=40 name=email>
              </font></td>
          </tr>
          <tr> 
            <td><font face="Geneva, Arial, Helvetica, san-serif" size="2">Fone(*):</font></td>

            <td> <font face="Geneva, Arial, Helvetica, san-serif" size="2"> 
              <input class=formbox size=7 name=ddd>
              &nbsp; 
              <input 
                  class=formbox maxlength=14 size=14 name=fone>
              </font></td>
          </tr>
          <tr> 
            <td colspan=2></td>
          </tr>
          <tr> 
            <td colspan=2></td>

          </tr>
          <tr> 
            <td colspan=2></td>
          </tr>
          <tr> 
            <td class=corpodetabela_bold><font face="Geneva, Arial, Helvetica, san-serif" size="2">Porto 
              de origem:</font></td>
            <td> <font face="Geneva, Arial, Helvetica, san-serif" size="2"> 
              <input class=formbox maxlength=40 size=40 name=origem>
              </font></td>

          </tr>
          <tr> 
            <td class=corpodetabela_bold><font face="Geneva, Arial, Helvetica, san-serif" size="2">Porto 
              de descarga:</font></td>
            <td> <font face="Geneva, Arial, Helvetica, san-serif" size="2"> 
              <input class=formbox maxlength=40 size=40 name=destino>
              </font></td>
          </tr>
          <tr> 
            <td class=corpodetabela_bold><font face="Geneva, Arial, Helvetica, san-serif" size="2">Quantidade 
              de containers:</font></td>

            <td class=corpodetexto_bold> <font face="Geneva, Arial, Helvetica, san-serif" size="2"> 
              <input class=formbox maxlength=4 
                  size=4 name=qtdcontainers>
              &nbsp;&nbsp;<span 
                  class=corpodetabela_bold>Tipo de container</span>&nbsp;&nbsp; 
              <select class=corpodetabela_bold size=1 name=tipocontainers>
                <option value="20 DC" selected>20' DC 
                <option 
                    value="20 FR">20' FR 
                <option value="20 RE">20' RE 
                <option 
                    value="20 OT">20' OT 
                <option value="40 DC">40' DC 
                <option 
                    value="40 FR">40' FR 
                <option value="40 RE">40' RE 
                <option 
                    value="40 OT">40' OT</option>

              </select>
              </font></td>
          </tr>
          <tr> 
            <td class=corpodetabela_bold><font face="Geneva, Arial, Helvetica, san-serif" size="2">Peso 
              da mercadoria em kg:</font></td>
            <td> <font face="Geneva, Arial, Helvetica, san-serif" size="2"> 
              <input class=formbox maxlength=20 name=peso>
              </font></td>
          </tr>

          <tr> 
            <td class=corpodetabela_bold><font face="Geneva, Arial, Helvetica, san-serif" size="2">Volume 
              mensal:</font></td>
            <td> <font face="Geneva, Arial, Helvetica, san-serif" size="2"> 
              <input class=formbox maxlength=20 name=volumemensal>
              </font></td>
          </tr>
          <tr> 
            <td class=corpodetabela_bold><font face="Geneva, Arial, Helvetica, san-serif" size="2">Carga 
              perigosa:</font></td>
            <td class=corpodetabela> <font face="Geneva, Arial, Helvetica, san-serif" size="2"> 
              <input type=radio value=sim 
                  name=cargaperigosa>

              sim &nbsp;&nbsp; 
              <input type=radio CHECKED 
                  value=n�o name=cargaperigosa>
              n�o </font></td>
          </tr>
          <tr> 
            <td class=corpodetabela_bold><font face="Geneva, Arial, Helvetica, san-serif" size="2">Carga 
              refrigerada: </font></td>
            <td class=corpodetabela> <font face="Geneva, Arial, Helvetica, san-serif" size="2"> 
              <input type=radio value=sim 
                  name=cargarefrigerada>

              sim &nbsp;&nbsp; 
              <input type=radio 
                  CHECKED value=n�o name=cargarefrigerada>
              n�o </font></td>
          </tr>
          <tr> 
            <td class=corpodetabela_bold align=middle 
              colspan=2>&nbsp;</td>
          </tr>
          <tr> 
            <td class=corpodetabela_bold 
                  valign=top height="100"><font face="Geneva, Arial, Helvetica, san-serif" size="2">&nbsp;<br>

              &nbsp;<br>
              Informa��es adicionais:<br>
              <input id=htmlresposta type=hidden 
                  value=cotacaor.html name=htmlresposta>
              </font></td>
            <td height="100"><font face="Geneva, Arial, Helvetica, san-serif" size="2"><span class=corpodetabela>(*) 
              campos obrigat�rios</span><br>
              <br>
              <textarea class=formbox name=mensagem rows=4 cols=40></textarea>

              <br>
              <input type=image height=17 width=63 
                  src="imagens/iconeb_enviar.gif" border=0 
                  name=enviar>
              </font></td>
          </tr>
          <tr> 
            <td colspan=2> 
              <center>
              </center>
            </td>
          </tr>


        </form>
        <font face="Geneva, Arial, Helvetica, san-serif" size="2"></TBODY>
        </font> 
      </table>
    </td>
    <td valign="top" width="130" rowspan="2" background="layout/projeto_r3_c5.jpg"> 
      <table width="86%" border="0" align="center" height="235">
        <tr> 
          <td height="442"> 
            <p><font size="2" face="Arial, Helvetica, sans-serif"><font face="Geneva, Arial, Helvetica, san-serif" size="1" color="#990000"><b><font color="#000000" size="2">Escrit&oacute;rios</font></b></font><font color="#000000" size="2"><b><font face="Geneva, Arial, Helvetica, san-serif"> 
              </font></b></font><b><font size="1" face="Geneva, Arial, Helvetica, san-serif"><br>

              </font><font size="2" face="Arial, Helvetica, sans-serif"><font face="Geneva, Arial, Helvetica, san-serif" size="1" color="#990000"><b></b></font></font><font size="1" face="Geneva, Arial, Helvetica, san-serif"> 
              <img src="layout/po.gif" width="12" height="11"> <a href="escr_no_brasil.htm">No 
              Brasil</a><br>
              </font><font size="2" face="Arial, Helvetica, sans-serif"><font face="Geneva, Arial, Helvetica, san-serif" size="1" color="#990000"><b><img src="layout/po.gif" width="12" height="11"></b></font></font> 
              <font size="1" face="Geneva, Arial, Helvetica, san-serif"><a href="escr_no_mundo.htm">No 
              Mundo</a></font></b></font></p>
            <p><b><font size="2" face="Geneva, Arial, Helvetica, san-serif">Programa&ccedil;&atilde;o 
              de Navios</font><font size="1" face="Geneva, Arial, Helvetica, san-serif"><br>
              </font><font size="2" face="Arial, Helvetica, sans-serif"><font face="Geneva, Arial, Helvetica, san-serif" size="1" color="#990000"><b><font color="#000000"><img src="layout/po.gif" width="12" height="11"></font></b></font></font> 
              <a href="asia.htm"><font size="1" face="Geneva, Arial, Helvetica, san-serif">Asia</font></a><font size="1" face="Geneva, Arial, Helvetica, san-serif"><br>

              </font><font size="2" face="Arial, Helvetica, sans-serif"><font face="Geneva, Arial, Helvetica, san-serif" size="1" color="#990000"><b><font color="#000000"><img src="layout/po.gif" width="12" height="11"></font></b></font></font> 
              <font size="1" face="Geneva, Arial, Helvetica, san-serif"><a href="europa.htm">Europa</a><br>
              </font><font size="2" face="Arial, Helvetica, sans-serif"><font face="Geneva, Arial, Helvetica, san-serif" size="1" color="#990000"><b><font color="#000000"><img src="layout/po.gif" width="12" height="11"></font></b></font></font> 
              <font size="1" face="Geneva, Arial, Helvetica, san-serif"><a href="eua.htm">E.U.A</a></font></b></p>
            <p><b><font size="2" face="Geneva, Arial, Helvetica, san-serif"><a href="exportacao.htm">Exporta&ccedil;&atilde;o</a></font></b></p>
            <p><b><font size="2" face="Geneva, Arial, Helvetica, san-serif">Cota&ccedil;&atilde;o 
              de Frete <br>
              </font><font size="1" face="Geneva, Arial, Helvetica, san-serif"><img src="layout/po.gif" width="12" height="11"> 
              <a href="orcamento_maritimo.htm">mar&iacute;timo</a></font><font size="1" face="Geneva, Arial, Helvetica, san-serif"><br>

              </font><font size="2" face="Arial, Helvetica, sans-serif"><font face="Geneva, Arial, Helvetica, san-serif" size="1" color="#990000"><b><font color="#000000"><img src="layout/po.gif" width="12" height="11"></font></b></font></font> 
              <font size="1" face="Geneva, Arial, Helvetica, san-serif"><a href="orcamento_aereo.htm">A&eacute;reo</a><br>
              </font><font size="2" face="Arial, Helvetica, sans-serif"><font face="Geneva, Arial, Helvetica, san-serif" size="1" color="#990000"><b><font color="#000000"><img src="layout/po.gif" width="12" height="11"></font></b></font></font> 
              <font size="1" face="Geneva, Arial, Helvetica, san-serif"><a href="orcamento_exportacao.htm">Exporta&ccedil;&atilde;o</a></font></b></p>
            <p><b><font size="2" face="Geneva, Arial, Helvetica, san-serif">Informa&ccedil;&otilde;es 
              &Uacute;teis:</font><font size="1" face="Geneva, Arial, Helvetica, san-serif"><br>
              </font> </b><font size="2" face="Geneva, Arial, Helvetica, san-serif">Convers&otilde;es</font><font size="1" face="Geneva, Arial, Helvetica, san-serif"></font><b><font size="1" face="Geneva, Arial, Helvetica, san-serif"><br>

              </font><font size="2" face="Arial, Helvetica, sans-serif"><font face="Geneva, Arial, Helvetica, san-serif" size="1" color="#990000"><b><font color="#000000"><img src="layout/po.gif" width="12" height="11"></font></b></font></font> 
              <font size="1" face="Geneva, Arial, Helvetica, san-serif"><a href="conversoes_distancia.htm">Dist&acirc;ncia</a><br>
              </font><font size="2" face="Arial, Helvetica, sans-serif"><font face="Geneva, Arial, Helvetica, san-serif" size="1" color="#990000"><b><font color="#000000"><img src="layout/po.gif" width="12" height="11"></font></b></font></font> 
              <font size="1" face="Geneva, Arial, Helvetica, san-serif"><a href="conversoes_aereas.htm">&Aacute;rea</a><br>
              </font><font size="2" face="Arial, Helvetica, sans-serif"><font face="Geneva, Arial, Helvetica, san-serif" size="1" color="#990000"><b><font color="#000000"><img src="layout/po.gif" width="12" height="11"></font></b></font></font> 
              <font size="1" face="Geneva, Arial, Helvetica, san-serif"><a href="conversoes_volume.htm">Volume</a><br>
              </font><font size="2" face="Arial, Helvetica, sans-serif"><font face="Geneva, Arial, Helvetica, san-serif" size="1" color="#990000"><b><font color="#000000"><img src="layout/po.gif" width="12" height="11"></font></b></font></font> 
              <font size="1" face="Geneva, Arial, Helvetica, san-serif"><a href="conversoes_peso.htm">Peso</a> 
              <br>

              </font><font size="2" face="Arial, Helvetica, sans-serif"><font face="Geneva, Arial, Helvetica, san-serif" size="1" color="#990000"><b><font color="#000000"><img src="layout/po.gif" width="12" height="11"></font></b></font></font> 
              <font size="1" face="Geneva, Arial, Helvetica, san-serif"><a href="conversoes_temperatura.htm">Temperatura</a></font></b></p>
            <p><b><font size="2" face="Arial, Helvetica, sans-serif"><font face="Geneva, Arial, Helvetica, san-serif" size="1" color="#990000"><b><font color="#000000"><img src="layout/po.gif" width="12" height="11"></font></b></font></font> 
              <font size="1" face="Geneva, Arial, Helvetica, san-serif"><a href="nossa_equipe.htm">Nossa 
              equipe</a></font></b></p>
            <p><b><font size="2" face="Geneva, Arial, Helvetica, san-serif"><a href="containers.htm">Container 
              </a><br>
              <a href="incoterms.htm">Incoterms</a></font></b></p>
          </td>
        </tr>

        <tr> 
          <td>&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td valign="top" height="31" width="662"> 
      <div align="center"></div>
    </td>

  </tr>
  <tr>
    <td valign="top" height="31" width="662"><font size="1" face="Arial, Helvetica, sans-serif">Rua 
      Chemim Del Pra n&ordm; 105/107 - Santana - Cep : 02016-060 S&atilde;o Paulo 
      - SP<br>
      Phone : 55 11 6281-3600 - Fax : 55 11 6281-3601 </font></td>
    <td valign="top" width="130" bgcolor="#666666"> 
      <div align="center"><font size="1" face="Arial, Helvetica, sans-serif"><b><font color="#FFFFFF">&copy; 
        2002 Hand Line <br>

        <a href="privacidade.htm">Pol&iacute;tica de Privacidade</a></font></b></font></div>
    </td>
  </tr>
</table>
<map name="Map">
  <area shape="rect" coords="26,98,75,110" href="home.htm">
  <area shape="rect" coords="96,100,228,111" href="fale_conosco.htm">
</map>
</body>
</html>

