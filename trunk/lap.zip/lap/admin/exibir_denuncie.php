<?php
include "../conn.php";
$consulta = mysql_query("SELECT * FROM denuncia") or die(mysql_error());

if ($_GET['ativar_id_cmt']) {
	mysql_query("UPDATE denuncia SET ativado = 0 WHERE id_cmt = '".$_GET['ativar_id_cmt']."'");
	echo "<script> window.location.href = 'exibir_denuncie.php'; </script>";
} 
 
if ($_GET['desativar_id_cmt']) {
	mysql_query("UPDATE denuncia SET ativado = 1 WHERE id_cmt = '".$_GET['desativar_id_cmt']."'");
	echo "<script> window.location.href = 'exibir_denuncie.php'; </script>"; 
} ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Ativar / Desativar denuncia</title>
</head>

<body>
</body>
</html>

<table width="500" border="0" cellpadding="2" cellspacing="2" class="boldamarelo">
<form name="ativar_form" method="post">
  <? 	while($mensagens = mysql_fetch_array($consulta)){ ?>
  <tr>
    <td width="56" bgcolor="#DBDAF8">C�digo Denuncia</td>
    <td width="128" bgcolor="#E2E2E2"><? echo $mensagens['id_cmt']; ?> </td>
  </tr>
  <tr>
    <td bgcolor="#DEDBFF">Nome</td>
    <td bgcolor="#E7E3E7"><? echo $mensagens['nome_cmt']; ?></td>
  </tr>
  <tr>
    <td bgcolor="#DEDBFF">Denuncia</td>
    <td bgcolor="#E7E3E7"><b><? echo $mensagens['texto_cmt']; ?></b></td>
  </tr>
  <tr>
    <td bgcolor="#DEDBFF">Data de Envio</td>
    <td bgcolor="#E7E3E7"><? echo $mensagens['data_cmt']; ?>-<? echo $mensagens['hora_cmt']; ?></td>
  </tr>
   <tr>
    <td bgcolor="#DEDBFF">Status</td>
    <td bgcolor="#E7E3E7"><? if ($mensagens['ativado']==1) { echo "desativado"; } else { echo "ativado";} ?></td>
  </tr>
  <tr>  
    <input name="id_cmt" id="id_cmt" type="hidden" value="<?=$mensagens['id_cmt']; ?>">
  <td colspan="2">
    <input name="deletar" type="button" class="botao" id="deletar" value="DELETAR" <? if ($mensagens['tipo'] == 1){ echo "disabled";}?>  onClick="javascript:location.href = 'deletar_denuncie.php?id_cmt=<?=$mensagens['id_cmt']; ?>'"/> 
 <?
if ($mensagens['ativado']==1) {
?>
  <input name="ativar" type="button" class="botao" id="ativar" value="Ativar" onClick="javascript:location.href = 'exibir_denuncie.php?ativar_id_cmt=<?=$mensagens['id_cmt']; ?>'"/>
<?
} elseif ($mensagens['ativado']==0) {
?>
  <input name="desativar" type="button" class="botao" id="desativar" value="Desativar" onClick="javascript:location.href = 'exibir_denuncie.php?desativar_id_cmt=<?=$mensagens['id_cmt']; ?>'"/>
<? } ?>
 </td>
  </tr>
  </form>
<? } ?>
</table>