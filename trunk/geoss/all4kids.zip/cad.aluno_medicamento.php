
<?php
require 'header.php';

include_once("class.aluno_medicamento.php");
$aluno_medicamento = new aluno_medicamento();

if($id){
	$aluno_medicamento->select($id);
}

$mensagem="$modo"."o";

?>
		<div class="conteudo-principal">
			<fieldset>
			<form role="form"  action="dao.php" method="post" enctype="multipart/form-data">
			<input type="hidden" name="id" value="<?php echo $id?>"> 
			<input type="hidden" name="type" value="aluno_medicamento">
			<span style="display:none" id="msg">Aluno medicamento <?php echo $mensagem?> com sucesso</span>
	<div class="form-group col-md-12" style="text-align: left">
				<?php
				$checked=($aluno_medicamento->tipo)?"checked":"";
				?>
				Tipo <input type="checkbox" name="tipo" value="1" <?php echo $checked ?>>
			    
					Tipo <input type="text" name="tipo" class=" form-control input-sm"  placeholder="Tipo" value="<?php echo $aluno_medicamento->tipo?>">
			                
		</div>
		
	<div class="form-group col-md-12" style="text-align: left">
					Causa <input type="text" name="causa" class=" form-control input-sm"  placeholder="Causa" value="<?php echo $aluno_medicamento->causa?>">
			                
		</div>
		
	<div class="form-group col-md-12" style="text-align: left">
					Medicacao <input type="text" name="medicacao" class=" form-control input-sm"  placeholder="Medicacao" value="<?php echo $aluno_medicamento->medicacao?>">
			                
		</div>
		
	<div class="form-group col-md-12" style="text-align: left">
					Dosagem <input type="text" name="dosagem" class=" form-control input-sm"  placeholder="Dosagem" value="<?php echo $aluno_medicamento->dosagem?>">
			                
		</div>
		
	<div class="form-group col-md-12" style="text-align: left">
					Horario <input type="text" name="horario" class=" form-control input-sm"  placeholder="Horario" value="<?php echo $aluno_medicamento->horario?>">
			                
		</div>
		
	<div class="form-group col-md-12" style="text-align: left">
			  <select class="form-control input-sm" name="idx_aluno">
					<option value="0">Selecione um Aluno</option>
					<?php
						$db = Database::getConnection();
						$sql = "SELECT id, nome
								FROM aluno
								ORDER BY nome";
						$res = $db->query( $sql );
						while ( $row = $res->fetch_assoc() ) {
							$checked=($aluno_medicamento->idx_aluno==$row['id'])?"selected":"";
							echo '<option value="'.$row['id'].'" '.$checked.'>'.$row['nome'].'</option>';
						}
					?>
			  </select>
			              
		</div>
							  <div class="form-group col-md-6 col-md-offset-3">
						<input type="submit" value="<?php echo $textoBotao?>" class="btn btn-info btn-block">
					  </div>	
					</form>
					</fieldset>
				  </div>

	<?php
           require 'footer.php'
    ?>
