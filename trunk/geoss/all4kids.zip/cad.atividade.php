<?php
require 'header.php';

include_once("class.atividade.php");
include_once("class.dia.php");
include_once("class.horario.php");

$atividade = new atividade();

if($id){
	$atividade->select($id);
}

$mensagem="$modo".a;
?>

<script type="text/javascript">
$(function() {	
	// Fullexample
	$( "#horario").tagedit({
		autocompleteURL: 'horario.php',
	});
});
$(function() {	
	// Fullexample
	$( "#dia").tagedit({
		autocompleteURL: 'dia.php',
	});
});
</script>

<div class="conteudo-principal">
    <fieldset>  
						<form role="form"  action="dao.php" onSubmit="return ajaxSubmit(this,'Atividade <?php echo $mensagem ?> com sucesso');">
						<input type="hidden" name="id" value="<?php echo $id?>"> 
						<input type="hidden" name="type" value="atividade">

						<div class="form-group col-md-12" style="text-align: left">
							Nome:
							<input type="text" name="nome" class=" form-control input-sm"  placeholder="Nome" value="<?php echo $atividade->nome?>">											
						</div>
		
					    <div class="form-group col-md-12" style="text-align: left">
							Vagas:
							<input type="text" name="vagas" class=" form-control input-sm"  placeholder="Vagas" value="<?php echo $atividade->vagas?>">								
					   </div>
					   
					   	<div class="form-group col-md-12" style="text-align: left">
							Valor:
							<input type="text" name="valor" class=" form-control input-sm"  placeholder="Valor" value="<?php echo $atividade->valor?>">
						</div>		
					
					   	<div class="form-group col-md-12" style="text-align: left">
							Dia:
							<input type="text" name="dia[]"  id="dia" class="tag form-control input-sm"  placeholder="Dia" value="<?php echo $atividade->dia?>">
						</div>	
							
						<div class="form-group col-md-12" style="text-align: left">
							Horario:
							<input type="text" name="horario[]" id="horario" class="tag form-control input-sm"  placeholder="Horario" value="<?php echo $atividade->horario?>">
						</div>	
					
		
					  <div class="form-group col-md-6 col-md-offset-3">
						<input type="submit" value="<?php echo $textoBotao?>" class="btn btn-info btn-block">
					  </div>	
					</form>
					
			</fieldset>
		</div>
	<?php
           require 'footer.php'
        ?>
