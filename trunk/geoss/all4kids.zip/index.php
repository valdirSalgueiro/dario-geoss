﻿<!DOCTYPE html>
<?php
require 'header.php';
?>

      <div class="featurette">
        <!--img class="featurette-image pull-left" src="img/semaforo.png"-->
        <h2 class="featurette-heading">All4Kids</span></h2>
        <p class="lead"></p>
      </div>
<?php
require 'footer.php'
?>
