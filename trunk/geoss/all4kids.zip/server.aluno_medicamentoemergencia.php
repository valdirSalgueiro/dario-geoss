
<?php

include_once("class.database.php");

$db = Database::getDb(); 


$table = 'medicamentoemergencia';
 
$primaryKey = 'id';
 
$columns = array(    

				array( 'db' => 'tipo', 'dt' => 0 ),
				
				array( 'db' => 'causa', 'dt' => 1 ),
				
				array( 'db' => 'medicacao', 'dt' => 2 ),
				
				array( 'db' => 'dosagem', 'dt' => 3 ),
				
				array( 'db' => 'horario', 'dt' => 4 ),
				
	array(
        'db'        => 'id',
        'dt'        => 5,
        'formatter' => function( $d, $row ) {
            return "<a href='cad.aluno_medicamento.php?id=$d' class='glyphicon glyphicon-edit'></a>";
        }
    ),	
	
	array(
        'db'        => 'id',
        'dt'        => 6,
        'formatter' => function( $d, $row ) {
            return "<a href='#' onclick='apagar(\"aluno_medicamento\",$d)' class='glyphicon glyphicon-remove'></a>";
        }
    ),
	
);
  
 
$sql_details = array(
    'user' => $db->user,
	'pass' => $db->password,
    'db'   => $db->database,
    'host' => $db->host
);
 
require( 'ssp.class.php' );
 
echo json_encode(
    SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns )
);
?>
