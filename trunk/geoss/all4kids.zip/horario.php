<?php

include_once('class.database.php');

$db = Database::getConnection();
$sql = "SELECT id, horario
		FROM horario
		ORDER BY horario";
$res = $db->query( $sql );
while ( $row = $res->fetch_assoc() ) {
	$autocompletiondata[$row['id']]=utf8_encode($row['horario']);
}

if(isset($_GET['term'])) {
    $result = array();
    foreach($autocompletiondata as $key => $value) {
        if(strlen($_GET['term']) == 0 || strpos(strtolower($value), strtolower($_GET['term'])) !== false) {
            $result[] = '{"id":'.$key.',"label":"'.$value.'","value":"'.$value.'"}';
        }
    }
    
    echo "[".implode(',', $result)."]";
}
?>