<form role="form"  action="dao.php" method="post" enctype="multipart/form-data"  onSubmit="return ajaxSubmit(this,'Medicamento cadastrado com sucesso');">
			<input type="hidden" name="type" value="aluno_medicamento">
			<input type="hidden" name="tipo" value="1">
			<input type="hidden" name="idx_aluno" value="<?php echo $id?>">
			
			<div class="form-group col-md-6" style="text-align: left">
						Causa <input type="text" name="causa" class=" form-control input-sm"  placeholder="Causa" value="<?php echo $aluno_medicamento->causa?>">
								
			</div>
			
		<div class="form-group col-md-6" style="text-align: left">
						Medicacao <input type="text" name="medicacao" class=" form-control input-sm"  placeholder="Medicacao" value="<?php echo $aluno_medicamento->medicacao?>">
								
			</div>
			
		<div class="form-group col-md-6" style="text-align: left">
						Dosagem <input type="text" name="dosagem" class=" form-control input-sm"  placeholder="Dosagem" value="<?php echo $aluno_medicamento->dosagem?>">
								
			</div>
			
		<div class="form-group col-md-6" style="text-align: left">
						Horario <input type="text" name="horario" class=" form-control input-sm"  placeholder="Horario" value="<?php echo $aluno_medicamento->horario?>">
								
			</div>
			
			<div class="form-group col-md-6 col-md-offset-3">
				<input type="submit" value="Cadastrar" class="btn btn-info btn-block">
			</div>	
	</form>