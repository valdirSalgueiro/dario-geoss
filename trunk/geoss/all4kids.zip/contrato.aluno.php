<html lang='en'>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name='viewport' content='width=device-width, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no' />
    <meta name="description" content="">
    <meta name="author" content="">
	<title>All4kids</title>
    <link href="css/bootstrap.css" rel="stylesheet"/>
</head>
<body>

<?php
function post($key) {
	if (isset($_REQUEST[$key]))
		return $_REQUEST[$key];
	return false;
}

	
$id = post('id')==0?0:post('id');
	
include_once("class.aluno.php");
$aluno = new aluno();

if($id){
	$aluno->select($id);
}


?>
		
	<div class="form-group col-md-6" style="text-align: left">
					Nome : <?php echo $aluno->nome?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Email :<?php echo $aluno->email?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Nome mae :<?php echo $aluno->nome_mae?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Nome pai :<?php echo $aluno->nome_pai?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Responsavel nome :<?php echo $aluno->responsavel_nome?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Responsavel cpf :<?php echo $aluno->responsavel_cpf?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Responsavel rg :<?php echo $aluno->responsavel_rg?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Endereco :<?php echo $aluno->endereco?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Plano saude :<?php echo $aluno->plano_saude?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Emergencia :<?php echo $aluno->emergencia?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Responsavel emergencia :<?php echo $aluno->responsavel_emergencia?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Carteira :<?php echo $aluno->carteira?>
			                
		</div>
		
		
	<div class="form-group col-md-6" style="text-align: left">
					Data de Nascimento: <?php echo $aluno->data_nasc?>
			                
		</div>
		
		
	<div class="form-group col-md-6" style="text-align: left">
					Naturalidade :<?php echo $aluno->naturalidade?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Uf :<?php echo $aluno->uf?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Pais :<?php echo $aluno->pais?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Numero :<?php echo $aluno->numero?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Complemento :<?php echo $aluno->complemento?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Bairro :<?php echo $aluno->bairro?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Cidade :<?php echo $aluno->cidade?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Estado :<?php echo $aluno->estado?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Cep :<?php echo $aluno->cep?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Reside :<?php echo $aluno->reside?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Reside outros :<?php echo $aluno->reside_outros?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Escola :<?php echo $aluno->escola?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Alergia :<?php echo $aluno->alergia?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Restricao alimentar :<?php echo $aluno->restricao_alimentar?>
			                
		</div>
		
	<div class="form-group col-md-6" style="text-align: left">
					Pessoas autorizadas :<?php echo $aluno->pessoas_autorizadas?>
			                
		</div>

</body>
</html>
	
